import { expect, test } from "@playwright/test";

test("rejects direct API access without identity, including a forged owner argument", async ({
  request,
}) => {
  const response = await request.get("/api/auth/session?ownerId=forged-user", {
    headers: { "x-user-id": "forged-user" },
  });
  expect(response.status()).toBe(401);
  expect(response.headers()["cache-control"]).toContain("no-store");
  expect(await response.json()).toEqual({
    success: false,
    error: { code: "AUTH_REQUIRED", message: "Please sign in to continue." },
  });

  const createResponse = await request.post("/api/analysis-targets", {
    data: {
      name: "Unauthenticated target",
      sourceUrl: "https://www.google.com/maps/place/NJIT",
      ownerId: "forged-user",
    },
  });
  expect(createResponse.status()).toBe(401);
  expect(createResponse.headers()["cache-control"]).toContain("no-store");
  expect(await createResponse.json()).toEqual({
    success: false,
    error: { code: "AUTH_REQUIRED", message: "Please sign in to continue." },
  });

  expect((await request.get("/api/health")).status()).toBe(200);
});

test("redirects protected navigation, returns after login, and rejects it again after logout", async ({
  page,
  context,
}) => {
  test.slow();

  // S1-015 owns this page; S1-010 owns the redirect and safe return flow.
  const destination = "/analysis-targets/new?source=direct";
  await page.goto(destination);
  await expect(page).toHaveURL(`/login?next=${encodeURIComponent(destination)}`);
  await page.getByLabel("Email *").fill("fixture@example.com");
  await page.getByLabel("Password *").fill("dummy-password");
  await page
    .getByRole("form", { name: "Sign in" })
    .getByRole("button", { name: "Sign in", exact: true })
    .click();
  await expect(page).toHaveURL(destination);
  await expect(page.getByRole("heading", { level: 1, name: "Create a new target" })).toBeVisible();
  expect((await context.request.get("/api/auth/session")).status()).toBe(200);

  await page.goto("/login");
  await expect(page).toHaveURL("/analysis-targets");
  await page.getByRole("button", { name: "fixture@example.com", exact: true }).click();
  await page.getByRole("menuitem", { name: "Sign out", exact: true }).click();
  await expect(page.getByRole("form", { name: "Sign in" })).toBeVisible();
  const response = await context.request.get(destination, { maxRedirects: 0 });
  expect(response.status()).toBe(303);
  expect(new URL(response.headers().location, response.url()).pathname).toBe("/login");
  const post = await context.request.post("/analysis-targets/new", {
    maxRedirects: 0,
    data: "dummy",
  });
  expect(post.status()).toBe(303);
});

test("ignores an external login destination", async ({ page }) => {
  await page.goto("/login?next=https%3A%2F%2Fexample.com");
  await page.getByLabel("Email *").fill("fixture@example.com");
  await page.getByLabel("Password *").fill("dummy-password");
  await page
    .getByRole("form", { name: "Sign in" })
    .getByRole("button", { name: "Sign in", exact: true })
    .click();
  await expect(page).toHaveURL("/analysis-targets");
  await expect(page.getByRole("heading", { name: "My Targets", exact: true })).toBeVisible();
  // A signed-in visit to login follows the same safe fallback.
  await page.goto("/login?next=https%3A%2F%2Fexample.com");
  await expect(page).toHaveURL("/analysis-targets");
});
