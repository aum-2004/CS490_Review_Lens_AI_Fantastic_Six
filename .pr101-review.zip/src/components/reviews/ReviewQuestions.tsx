"use client";

import { useLayoutEffect, useId, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { CircleAlert } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import {
  Form,
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage,
} from "@/components/ui/Form";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/Alert";
import { Spinner } from "@/components/shared/Spinner";
import {
  askReviewQuestion,
  ReviewQuestionError,
  type ReviewAnswer,
} from "@/lib/api/review-questions";
import { reviewQuestionSchema } from "@/lib/validation/review-question";

type Props = {
  userId: string;
  targetId: string;
  targetName: string;
  reviewsAvailable: boolean;
  unavailableMessage?: string;
};

const outcomeLabels = {
  answered: "ReviewLens response",
  insufficient_evidence: "Insufficient review evidence",
  out_of_scope: "Outside the active reviews",
};

export function ReviewQuestions(props: Props) {
  const { bfcacheId } = useRouter();
  // Scope state to the verified account as well as the target and navigation.
  // Back/forward restores bfcacheId; Activity cleanup below handles that transition.
  return (
    <QuestionForm
      key={`${props.userId}:${props.targetId}:${bfcacheId}:${props.reviewsAvailable}`}
      {...props}
    />
  );
}

function QuestionForm({
  targetId,
  targetName,
  reviewsAvailable,
  unavailableMessage = "No saved reviews are available for this target. Complete ingestion in the Ingestion panel before asking ReviewLens questions.",
}: Props) {
  const router = useRouter();
  const questionHelpId = useId();
  const unavailableHelpId = useId();
  const questionDescription = reviewsAvailable
    ? questionHelpId
    : `${questionHelpId} ${unavailableHelpId}`;
  const request = useRef<AbortController | null>(null);
  const [pending, setPending] = useState(false);
  const [answer, setAnswer] = useState<ReviewAnswer | null>(null);
  const [answeredQuestion, setAnsweredQuestion] = useState("");
  const [error, setError] = useState<string | null>(null);
  const form = useForm<{ question: string }>({
    resolver: zodResolver(reviewQuestionSchema),
    defaultValues: { question: "" },
  });

  const { reset } = form;
  useLayoutEffect(
    () => () => {
      request.current?.abort();
      request.current = null;
      // Activity preserves hidden pages; clear all transient Q&A state before restoration.
      setAnswer(null);
      setAnsweredQuestion("");
      setError(null);
      setPending(false);
      reset({ question: "" });
    },
    [reset],
  );

  const submit = async ({ question }: { question: string }) => {
    if (request.current || !reviewsAvailable) return;
    const controller = new AbortController();
    request.current = controller;
    setPending(true);
    // The provider now has separate 30s counting and generation deadlines.
    const timeout = setTimeout(() => controller.abort(), 75_000);
    setAnswer(null);
    setError(null);
    try {
      const result = await askReviewQuestion(targetId, question, controller.signal);
      if (controller.signal.aborted || request.current !== controller) return;
      setAnsweredQuestion(question);
      setAnswer(result);
    } catch (cause) {
      // Unmount aborts must not affect the newly selected workspace.
      if (request.current !== controller) return;
      if (cause instanceof ReviewQuestionError && cause.fieldErrors?.question) {
        form.setError(
          "question",
          { type: "server", message: cause.fieldErrors.question },
          { shouldFocus: true },
        );
        return;
      }
      if (cause instanceof ReviewQuestionError && cause.code === "AUTHENTICATION_REQUIRED") {
        router.replace(`/login?next=${encodeURIComponent(`/analysis-targets/${targetId}`)}`);
      }
      setError(
        cause instanceof ReviewQuestionError
          ? cause.message
          : "We couldn't answer your question. Please try again.",
      );
    } finally {
      clearTimeout(timeout);
      // Old requests must not clear a newer request after Activity restoration.
      if (request.current === controller) {
        request.current = null;
        setPending(false);
      }
    }
  };

  return (
    <Card className="space-y-4" aria-label="Review questions">
      <h2 className="text-xl font-semibold">Ask ReviewLens</h2>
      <p id={questionHelpId} className="max-w-prose break-words text-sm text-muted-foreground">
        Active target: <span className="font-medium text-foreground">{targetName}</span> · Google
        Maps. Ask questions about this target&apos;s saved reviews. Each account can make five
        attempts within 24 hours. Failed answer-service attempts also count.
      </p>
      {!reviewsAvailable && (
        <Alert role="status">
          <CircleAlert aria-hidden="true" />
          <AlertTitle>Review questions unavailable</AlertTitle>
          <AlertDescription id={unavailableHelpId}>{unavailableMessage}</AlertDescription>
        </Alert>
      )}
      <Form {...form}>
        <form
          className="space-y-4"
          noValidate
          onSubmit={(event) => void form.handleSubmit(submit)(event)}
          aria-busy={pending}
        >
          <p className="text-sm text-muted-foreground">* Required</p>
          <FormField
            control={form.control}
            name="question"
            render={({ field }) => (
              <FormItem>
                <FormLabel>
                  Question <span aria-hidden="true">*</span>
                </FormLabel>
                <FormControl aria-describedby={questionDescription}>
                  <Input
                    {...field}
                    aria-required="true"
                    disabled={!reviewsAvailable}
                    readOnly={pending}
                    placeholder="What do reviewers like about this business?"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          {error && (
            <Alert variant="destructive">
              <CircleAlert aria-hidden="true" />
              <AlertTitle>Question not answered</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          <div className="flex justify-end">
            <Button
              type="submit"
              className="w-40"
              disabled={!reviewsAvailable || pending}
              aria-describedby={reviewsAvailable ? undefined : unavailableHelpId}
            >
              {pending ? (
                <>
                  <Spinner /> Asking…
                </>
              ) : (
                "Ask question"
              )}
            </Button>
          </div>
        </form>
      </Form>
      <div role="status" aria-live="polite" aria-atomic="true" className="space-y-3">
        {pending && (
          <p className="break-words text-sm text-muted-foreground">
            ReviewLens is processing your question for {targetName}…
          </p>
        )}
        {answer && !pending && (
          <>
            <h3 className="text-lg font-medium">{outcomeLabels[answer.outcome]}</h3>
            <p className="max-w-prose break-words text-sm text-muted-foreground">
              Question: {answeredQuestion}
            </p>
            <p className="max-w-prose whitespace-pre-wrap break-words">{answer.answer}</p>
          </>
        )}
      </div>
    </Card>
  );
}
